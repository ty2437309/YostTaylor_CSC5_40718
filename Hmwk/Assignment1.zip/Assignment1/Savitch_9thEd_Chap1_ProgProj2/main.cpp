/* 
 * File:   main.cpp
 * Author: Taylor Yost
 * Created on January 8, 2015, 08:32
 * Purpose: Chapter 1 Programming Projects Homework (Savitch 9th)
 */

//System Libraries
#include <iostream>
using namespace std;

//User Libraries

//Global Constants

//Function Prototypes

//Execution Begins Here!
int main(int argc, char** argv) {
    //Begin Drawing
    cout<<"************************************************** \n";
    cout<<" \n";
    cout<<" \n";
    cout<<"           C C C            S S S S        !! \n";
    cout<<"         C       C        S         S      !! \n";
    cout<<"        C                S                 !! \n";
    cout<<"       C                  S                !! \n";
    cout<<"       C                    S S S S        !! \n";
    cout<<"       C                            S      !! \n";
    cout<<"        C                            S     !! \n";
    cout<<"         C       C        S         S      !! \n";
    cout<<"           C C C            S S S S        00 \n";
    cout<<" \n";
    cout<<" \n";
    cout<<"************************************************** \n";
    cout<<"         Computer Science is Cool Stuff!!!"<<endl;
    //Exit stage right!
    return 0;
}

